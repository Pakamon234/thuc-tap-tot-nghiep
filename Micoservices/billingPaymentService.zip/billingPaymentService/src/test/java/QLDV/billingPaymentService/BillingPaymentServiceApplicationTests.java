package QLDV.billingPaymentService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BillingPaymentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
