package QLDV.addendumService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AddendumServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AddendumServiceApplication.class, args);
	}

}
