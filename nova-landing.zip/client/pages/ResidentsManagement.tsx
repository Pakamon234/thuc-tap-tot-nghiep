import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  MoreHorizontal, 
  UserPlus, 
  CheckCircle, 
  XCircle, 
  Edit3, 
  Eye,
  Mail,
  Phone,
  Building
} from 'lucide-react';
import { cn } from '../lib/utils';

interface Resident {
  id: string;
  name: string;
  email: string;
  phone: string;
  apartmentNumber: string;
  status: 'pending' | 'approved' | 'rejected' | 'suspended';
  registrationDate: string;
  lastLogin?: string;
}

const ResidentsManagement: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedResident, setSelectedResident] = useState<Resident | null>(null);
  const [showDetails, setShowDetails] = useState(false);

  // Mock data
  const residents: Resident[] = [
    {
      id: '1',
      name: 'Nguyễn Văn An',
      email: 'nguyen.van.an@email.com',
      phone: '0123456789',
      apartmentNumber: 'A101',
      status: 'approved',
      registrationDate: '2024-01-15',
      lastLogin: '2024-12-10'
    },
    {
      id: '2',
      name: 'Trần Thị Bích',
      email: 'tran.thi.bich@email.com',
      phone: '0987654321',
      apartmentNumber: 'B205',
      status: 'pending',
      registrationDate: '2024-12-08'
    },
    {
      id: '3',
      name: 'Lê Minh Cường',
      email: 'le.minh.cuong@email.com',
      phone: '0345678901',
      apartmentNumber: 'C302',
      status: 'approved',
      registrationDate: '2024-11-20',
      lastLogin: '2024-12-09'
    },
    {
      id: '4',
      name: 'Hoàng Thị Diệu',
      email: 'hoang.thi.dieu@email.com',
      phone: '0567890123',
      apartmentNumber: 'A205',
      status: 'suspended',
      registrationDate: '2024-10-10',
      lastLogin: '2024-11-15'
    }
  ];

  const filteredResidents = residents.filter(resident => {
    const matchesSearch = resident.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resident.apartmentNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resident.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || resident.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    const styles = {
      pending: 'bg-yellow-100 text-yellow-800',
      approved: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800',
      suspended: 'bg-gray-100 text-gray-800'
    };
    
    const labels = {
      pending: 'Chờ duyệt',
      approved: 'Đã duyệt',
      rejected: 'Từ chối',
      suspended: 'Tạm khóa'
    };

    return (
      <span className={cn('px-2 py-1 rounded-full text-xs font-medium', styles[status as keyof typeof styles])}>
        {labels[status as keyof typeof labels]}
      </span>
    );
  };

  const handleStatusChange = (residentId: string, newStatus: 'approved' | 'rejected' | 'suspended') => {
    console.log(`Changing status of resident ${residentId} to ${newStatus}`);
    // Here you would make an API call to update the status
  };

  const statistics = [
    { label: 'Tổng cư dân', value: residents.length, color: 'text-blue-600' },
    { label: 'Chờ duyệt', value: residents.filter(r => r.status === 'pending').length, color: 'text-yellow-600' },
    { label: 'Đã duyệt', value: residents.filter(r => r.status === 'approved').length, color: 'text-green-600' },
    { label: 'Tạm khóa', value: residents.filter(r => r.status === 'suspended').length, color: 'text-red-600' }
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Quản lý cư dân</h1>
          <p className="text-gray-600 mt-1">Quản lý tài khoản và thông tin cư dân chung cư</p>
        </div>
        <button className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-600 transition-colors flex items-center">
          <UserPlus className="h-4 w-4 mr-2" />
          Thêm cư dân
        </button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {statistics.map((stat, index) => (
          <div key={index} className="bg-white rounded-lg p-4 border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                <p className={cn('text-2xl font-bold', stat.color)}>{stat.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg p-4 border">
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search */}
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Tìm kiếm theo tên, căn hộ hoặc email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
            </div>
          </div>

          {/* Status Filter */}
          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-gray-500" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            >
              <option value="all">Tất cả trạng thái</option>
              <option value="pending">Chờ duyệt</option>
              <option value="approved">Đã duyệt</option>
              <option value="rejected">Từ chối</option>
              <option value="suspended">Tạm khóa</option>
            </select>
          </div>
        </div>
      </div>

      {/* Residents Table */}
      <div className="bg-white rounded-lg border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Cư dân
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Căn hộ
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Liên hệ
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Trạng thái
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ngày đăng ký
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Thao tác
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredResidents.map((resident) => (
                <tr key={resident.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-10 w-10 bg-primary rounded-full flex items-center justify-center text-white font-medium">
                        {resident.name.charAt(0)}
                      </div>
                      <div className="ml-3">
                        <div className="text-sm font-medium text-gray-900">{resident.name}</div>
                        <div className="text-sm text-gray-500">{resident.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Building className="h-4 w-4 text-gray-400 mr-2" />
                      <span className="text-sm font-medium text-gray-900">{resident.apartmentNumber}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="space-y-1">
                      <div className="flex items-center text-sm text-gray-600">
                        <Mail className="h-3 w-3 mr-1" />
                        {resident.email}
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <Phone className="h-3 w-3 mr-1" />
                        {resident.phone}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {getStatusBadge(resident.status)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {new Date(resident.registrationDate).toLocaleDateString('vi-VN')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => {setSelectedResident(resident); setShowDetails(true);}}
                        className="text-blue-600 hover:text-blue-900 p-1 rounded"
                        title="Xem chi tiết"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      {resident.status === 'pending' && (
                        <>
                          <button
                            onClick={() => handleStatusChange(resident.id, 'approved')}
                            className="text-green-600 hover:text-green-900 p-1 rounded"
                            title="Duyệt"
                          >
                            <CheckCircle className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => handleStatusChange(resident.id, 'rejected')}
                            className="text-red-600 hover:text-red-900 p-1 rounded"
                            title="Từ chối"
                          >
                            <XCircle className="h-4 w-4" />
                          </button>
                        </>
                      )}
                      <button className="text-gray-600 hover:text-gray-900 p-1 rounded" title="Chỉnh sửa">
                        <Edit3 className="h-4 w-4" />
                      </button>
                      <button className="text-gray-600 hover:text-gray-900 p-1 rounded">
                        <MoreHorizontal className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredResidents.length === 0 && (
          <div className="text-center py-8">
            <p className="text-gray-500">Không tìm thấy cư dân nào phù hợp</p>
          </div>
        )}
      </div>

      {/* Resident Details Modal */}
      {showDetails && selectedResident && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Chi tiết cư dân</h3>
              <button 
                onClick={() => setShowDetails(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <XCircle className="h-5 w-5" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="h-12 w-12 bg-primary rounded-full flex items-center justify-center text-white font-medium text-lg">
                  {selectedResident.name.charAt(0)}
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">{selectedResident.name}</h4>
                  {getStatusBadge(selectedResident.status)}
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-600">Căn hộ</label>
                  <p className="text-gray-900">{selectedResident.apartmentNumber}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Số điện thoại</label>
                  <p className="text-gray-900">{selectedResident.phone}</p>
                </div>
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-600">Email</label>
                <p className="text-gray-900">{selectedResident.email}</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-600">Ngày đăng ký</label>
                  <p className="text-gray-900">{new Date(selectedResident.registrationDate).toLocaleDateString('vi-VN')}</p>
                </div>
                {selectedResident.lastLogin && (
                  <div>
                    <label className="text-sm font-medium text-gray-600">Đăng nhập cuối</label>
                    <p className="text-gray-900">{new Date(selectedResident.lastLogin).toLocaleDateString('vi-VN')}</p>
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex space-x-3 mt-6">
              <button 
                onClick={() => setShowDetails(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Đóng
              </button>
              <button className="flex-1 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-600">
                Chỉnh sửa
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ResidentsManagement;
