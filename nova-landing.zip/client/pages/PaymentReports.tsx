import React, { useState } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Download, 
  Calendar, 
  Filter,
  DollarSign,
  FileText,
  Building,
  Users,
  PieChart,
  Activity
} from 'lucide-react';
import { cn } from '../lib/utils';

const PaymentReports: React.FC = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('month');
  const [selectedYear, setSelectedYear] = useState('2024');
  const [selectedMonth, setSelectedMonth] = useState('12');

  // Mock data for charts and reports
  const monthlyRevenue = [
    { month: 'T1', amount: 45000000, apartments: 120, paymentRate: 85 },
    { month: 'T2', amount: 47000000, apartments: 122, paymentRate: 88 },
    { month: 'T3', amount: 44000000, apartments: 118, paymentRate: 82 },
    { month: 'T4', amount: 48000000, apartments: 125, paymentRate: 90 },
    { month: 'T5', amount: 46000000, apartments: 123, paymentRate: 87 },
    { month: 'T6', amount: 49000000, apartments: 128, paymentRate: 92 },
    { month: 'T7', amount: 50000000, apartments: 130, paymentRate: 94 },
    { month: 'T8', amount: 48000000, apartments: 127, paymentRate: 89 },
    { month: 'T9', amount: 51000000, apartments: 132, paymentRate: 95 },
    { month: 'T10', amount: 52000000, apartments: 134, paymentRate: 96 },
    { month: 'T11', amount: 49000000, apartments: 129, paymentRate: 91 },
    { month: 'T12', amount: 53000000, apartments: 136, paymentRate: 97 }
  ];

  const serviceBreakdown = [
    { name: 'Phí quản lý', amount: 28000000, percentage: 53, color: 'bg-blue-500' },
    { name: 'Điện', amount: 12000000, percentage: 23, color: 'bg-yellow-500' },
    { name: 'Nước', amount: 6000000, percentage: 11, color: 'bg-cyan-500' },
    { name: 'Bảo vệ', amount: 4000000, percentage: 8, color: 'bg-red-500' },
    { name: 'Gửi xe', amount: 2000000, percentage: 4, color: 'bg-purple-500' },
    { name: 'Khác', amount: 1000000, percentage: 1, color: 'bg-gray-500' }
  ];

  const apartmentPayments = [
    { apartment: 'A101', resident: 'Nguyễn Văn An', amount: 2450000, status: 'paid', dueDate: '2024-12-15' },
    { apartment: 'A102', resident: 'Trần Thị Bích', amount: 1980000, status: 'paid', dueDate: '2024-12-15' },
    { apartment: 'A103', resident: 'Lê Minh Cường', amount: 2750000, status: 'overdue', dueDate: '2024-11-15' },
    { apartment: 'B201', resident: 'Phạm Thị Dung', amount: 2200000, status: 'pending', dueDate: '2024-12-15' },
    { apartment: 'B202', resident: 'Hoàng Văn Em', amount: 2100000, status: 'paid', dueDate: '2024-12-15' }
  ];

  const statistics = [
    {
      title: 'Tổng doanh thu tháng này',
      value: '53,000,000',
      unit: 'VND',
      change: '+8.2%',
      changeType: 'increase',
      icon: DollarSign,
      color: 'text-green-600'
    },
    {
      title: 'Tỷ lệ thanh toán',
      value: '97',
      unit: '%',
      change: '+2.1%',
      changeType: 'increase',
      icon: TrendingUp,
      color: 'text-blue-600'
    },
    {
      title: 'Số căn hộ đã thanh toán',
      value: '132',
      unit: '/136',
      change: '+4',
      changeType: 'increase',
      icon: Building,
      color: 'text-purple-600'
    },
    {
      title: 'Hóa đơn chưa thanh toán',
      value: '4',
      unit: 'hóa đơn',
      change: '-2',
      changeType: 'decrease',
      icon: FileText,
      color: 'text-orange-600'
    }
  ];

  const getStatusBadge = (status: string) => {
    const styles = {
      paid: 'bg-green-100 text-green-800',
      pending: 'bg-yellow-100 text-yellow-800',
      overdue: 'bg-red-100 text-red-800'
    };
    
    const labels = {
      paid: 'Đã thanh toán',
      pending: 'Chờ thanh toán',
      overdue: 'Quá hạn'
    };

    return (
      <span className={cn('px-2 py-1 rounded-full text-xs font-medium', styles[status as keyof typeof styles])}>
        {labels[status as keyof typeof labels]}
      </span>
    );
  };

  const maxAmount = Math.max(...monthlyRevenue.map(item => item.amount));

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Báo cáo thanh toán</h1>
          <p className="text-gray-600 mt-1">Thống kê và phân tích doanh thu từ các dịch vụ</p>
        </div>
        <div className="flex space-x-3">
          <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center">
            <Download className="h-4 w-4 mr-2" />
            Xuất Excel
          </button>
          <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors flex items-center">
            <Download className="h-4 w-4 mr-2" />
            Xuất PDF
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg p-4 border">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex items-center space-x-2">
            <Calendar className="h-4 w-4 text-gray-500" />
            <select
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="month">Theo tháng</option>
              <option value="quarter">Theo quý</option>
              <option value="year">Theo năm</option>
            </select>
          </div>

          <div className="flex items-center space-x-2">
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="2024">Năm 2024</option>
              <option value="2023">Năm 2023</option>
            </select>
          </div>

          {selectedPeriod === 'month' && (
            <div className="flex items-center space-x-2">
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="12">Tháng 12</option>
                <option value="11">Tháng 11</option>
                <option value="10">Tháng 10</option>
              </select>
            </div>
          )}
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statistics.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-lg p-6 border">
              <div className="flex items-center justify-between mb-4">
                <Icon className={cn('h-8 w-8', stat.color)} />
                <span className={cn(
                  'text-sm font-medium flex items-center',
                  stat.changeType === 'increase' ? 'text-green-600' : 'text-red-600'
                )}>
                  <TrendingUp className="h-4 w-4 mr-1" />
                  {stat.change}
                </span>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                <p className="text-2xl font-bold text-gray-900">
                  {stat.value} <span className="text-sm font-normal text-gray-600">{stat.unit}</span>
                </p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <div className="lg:col-span-2 bg-white rounded-lg p-6 border">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Doanh thu theo tháng</h3>
            <div className="flex items-center space-x-2">
              <BarChart3 className="h-5 w-5 text-gray-500" />
              <span className="text-sm text-gray-600">2024</span>
            </div>
          </div>
          
          <div className="space-y-4">
            {monthlyRevenue.map((item, index) => (
              <div key={index} className="flex items-center space-x-4">
                <div className="w-8 text-sm text-gray-600 font-medium">{item.month}</div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-gray-900">
                      {item.amount.toLocaleString('vi-VN')} VND
                    </span>
                    <span className="text-xs text-gray-500">{item.paymentRate}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-primary h-2 rounded-full" 
                      style={{ width: `${(item.amount / maxAmount) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Service Breakdown */}
        <div className="bg-white rounded-lg p-6 border">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Phân tích dịch vụ</h3>
            <PieChart className="h-5 w-5 text-gray-500" />
          </div>
          
          <div className="space-y-3">
            {serviceBreakdown.map((service, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={cn('w-3 h-3 rounded-full', service.color)} />
                  <span className="text-sm font-medium text-gray-900">{service.name}</span>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium text-gray-900">{service.percentage}%</div>
                  <div className="text-xs text-gray-500">
                    {service.amount.toLocaleString('vi-VN')} VND
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Payment Details Table */}
      <div className="bg-white rounded-lg border">
        <div className="px-6 py-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">Chi tiết thanh toán theo căn hộ</h3>
            <div className="flex items-center space-x-2">
              <Filter className="h-4 w-4 text-gray-500" />
              <select className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary">
                <option value="all">Tất cả trạng thái</option>
                <option value="paid">Đã thanh toán</option>
                <option value="pending">Chờ thanh toán</option>
                <option value="overdue">Quá hạn</option>
              </select>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Căn hộ
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Cư dân
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Số tiền
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Hạn thanh toán
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Trạng thái
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {apartmentPayments.map((payment, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Building className="h-4 w-4 text-gray-400 mr-2" />
                      <span className="text-sm font-medium text-gray-900">{payment.apartment}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-900">{payment.resident}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm font-medium text-gray-900">
                      {payment.amount.toLocaleString('vi-VN')} VND
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-900">
                      {new Date(payment.dueDate).toLocaleDateString('vi-VN')}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {getStatusBadge(payment.status)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PaymentReports;
