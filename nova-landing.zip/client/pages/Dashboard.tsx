import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { 
  Users, 
  FileText, 
  CreditCard, 
  BarChart3, 
  Bell,
  Clock,
  CheckCircle,
  AlertTriangle,
  TrendingUp,
  Building2
} from 'lucide-react';
import { Link } from 'react-router-dom';

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  const currentTime = new Date().toLocaleString('vi-VN', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  const ManagementDashboard = () => (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-primary to-primary-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Chào mừng, {user?.name}</h1>
            <p className="text-primary-100 mt-1">Ban quản lý chung cư</p>
            <p className="text-primary-200 text-sm mt-2">{currentTime}</p>
          </div>
          <Building2 className="h-16 w-16 text-primary-200" />
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Tổng cư dân</p>
              <p className="text-2xl font-bold text-gray-900">124</p>
            </div>
            <Users className="h-8 w-8 text-blue-600" />
          </div>
          <div className="mt-4 flex items-center text-sm">
            <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-green-600">+8 tháng này</span>
          </div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Hóa đơn chưa thanh toán</p>
              <p className="text-2xl font-bold text-gray-900">23</p>
            </div>
            <FileText className="h-8 w-8 text-orange-600" />
          </div>
          <div className="mt-4 flex items-center text-sm">
            <AlertTriangle className="h-4 w-4 text-orange-500 mr-1" />
            <span className="text-orange-600">Cần xử lý</span>
          </div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Doanh thu tháng này</p>
              <p className="text-2xl font-bold text-gray-900">1.2M</p>
            </div>
            <BarChart3 className="h-8 w-8 text-green-600" />
          </div>
          <div className="mt-4 flex items-center text-sm">
            <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-green-600">+12% so với tháng trước</span>
          </div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Hợp đồng sắp hết hạn</p>
              <p className="text-2xl font-bold text-gray-900">7</p>
            </div>
            <Clock className="h-8 w-8 text-red-600" />
          </div>
          <div className="mt-4 flex items-center text-sm">
            <AlertTriangle className="h-4 w-4 text-red-500 mr-1" />
            <span className="text-red-600">Trong 30 ngày tới</span>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Thao tác nhanh</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <Link
            to="/residents"
            className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <Users className="h-8 w-8 text-blue-600 mr-3" />
            <div>
              <p className="font-medium text-gray-900">Quản lý cư dân</p>
              <p className="text-sm text-gray-600">Duyệt tài khoản, quản lý thông tin</p>
            </div>
          </Link>

          <Link
            to="/services"
            className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <FileText className="h-8 w-8 text-green-600 mr-3" />
            <div>
              <p className="font-medium text-gray-900">Cấu hình dịch vụ</p>
              <p className="text-sm text-gray-600">Thiết lập giá, điều khoản</p>
            </div>
          </Link>

          <Link
            to="/invoices"
            className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <CreditCard className="h-8 w-8 text-purple-600 mr-3" />
            <div>
              <p className="font-medium text-gray-900">Lập hóa đơn</p>
              <p className="text-sm text-gray-600">Tạo và quản lý hóa đơn</p>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );

  const ResidentDashboard = () => (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-primary to-primary-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Xin chào, {user?.name}</h1>
            <p className="text-primary-100 mt-1">Căn hộ {user?.apartmentNumber}</p>
            <p className="text-primary-200 text-sm mt-2">{currentTime}</p>
          </div>
          <Building2 className="h-16 w-16 text-primary-200" />
        </div>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Hợp đồng đang hiệu lực</p>
              <p className="text-2xl font-bold text-gray-900">5</p>
            </div>
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          <p className="text-sm text-green-600 mt-2">Tất cả đều ổn</p>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Hóa đơn chưa thanh toán</p>
              <p className="text-2xl font-bold text-gray-900">3</p>
            </div>
            <FileText className="h-8 w-8 text-orange-600" />
          </div>
          <p className="text-sm text-orange-600 mt-2">Tổng: 2.450.000 VND</p>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Thông báo mới</p>
              <p className="text-2xl font-bold text-gray-900">2</p>
            </div>
            <Bell className="h-8 w-8 text-blue-600" />
          </div>
          <p className="text-sm text-blue-600 mt-2">Có thông báo mới</p>
        </div>
      </div>

      {/* Recent Activities */}
      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Hoạt động gần đây</h2>
        <div className="space-y-4">
          <div className="flex items-center p-3 bg-blue-50 rounded-lg">
            <FileText className="h-5 w-5 text-blue-600 mr-3" />
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-900">Hóa đơn tháng 12 đã được tạo</p>
              <p className="text-xs text-gray-600">2 ngày trước</p>
            </div>
          </div>
          
          <div className="flex items-center p-3 bg-green-50 rounded-lg">
            <CheckCircle className="h-5 w-5 text-green-600 mr-3" />
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-900">Thanh toán hóa đơn tháng 11 thành công</p>
              <p className="text-xs text-gray-600">1 tuần trước</p>
            </div>
          </div>

          <div className="flex items-center p-3 bg-yellow-50 rounded-lg">
            <Bell className="h-5 w-5 text-yellow-600 mr-3" />
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-900">Hợp đồng dịch vụ vệ sinh sắp hết hạn</p>
              <p className="text-xs text-gray-600">3 ngày trước</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Thao tác nhanh</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Link
            to="/payments"
            className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <CreditCard className="h-8 w-8 text-green-600 mr-3" />
            <div>
              <p className="font-medium text-gray-900">Thanh toán hóa đơn</p>
              <p className="text-sm text-gray-600">3 hóa đơn chưa thanh toán</p>
            </div>
          </Link>

          <Link
            to="/my-contracts"
            className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <FileText className="h-8 w-8 text-blue-600 mr-3" />
            <div>
              <p className="font-medium text-gray-900">Xem hợp đồng</p>
              <p className="text-sm text-gray-600">Quản lý 5 hợp đồng</p>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );

  return (
    <div className="p-6">
      {user?.role === 'management' ? <ManagementDashboard /> : <ResidentDashboard />}
    </div>
  );
};

export default Dashboard;
