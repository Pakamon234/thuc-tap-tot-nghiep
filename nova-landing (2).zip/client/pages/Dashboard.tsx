import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { reportsService } from '../services/reportsService';
import { invoicesService } from '../services/invoicesService';
import { residentsService } from '../services/residentsService';
import Loading, { StatsLoading } from '../components/Loading';
import { ErrorFallback } from '../components/ErrorBoundary';
import { handleApiError } from '../services/api';
import {
  Users,
  FileText,
  CreditCard,
  BarChart3,
  Bell,
  Clock,
  CheckCircle,
  AlertTriangle,
  TrendingUp,
  Building2
} from 'lucide-react';
import { Link } from 'react-router-dom';

interface DashboardStats {
  residents: { total: number; pending: number; approved: number; suspended: number };
  invoices: { total: number; pending: number; paid: number; overdue: number };
  revenue: { monthly: number; growth: number };
  contracts: { active: number; expiring: number };
}

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const [dashboardStats, setDashboardStats] = useState<DashboardStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const currentTime = new Date().toLocaleString('vi-VN', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  useEffect(() => {
    if (user?.role === 'management') {
      loadDashboardStats();
    } else {
      loadResidentDashboard();
    }
  }, [user]);

  const loadDashboardStats = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const stats = await reportsService.getDashboardStats();
      setDashboardStats(stats);
    } catch (err: any) {
      setError(handleApiError(err));
    } finally {
      setIsLoading(false);
    }
  };

  const loadResidentDashboard = async () => {
    setIsLoading(true);
    setError(null);
    try {
      // Load resident-specific data
      // This will be implemented when we have resident endpoints
      setIsLoading(false);
    } catch (err: any) {
      setError(handleApiError(err));
    } finally {
      setIsLoading(false);
    }
  };

  const handleRetry = () => {
    if (user?.role === 'management') {
      loadDashboardStats();
    } else {
      loadResidentDashboard();
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="bg-gradient-to-r from-primary to-primary-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <div className="h-8 bg-white bg-opacity-20 rounded w-48 mb-2"></div>
              <div className="h-4 bg-white bg-opacity-20 rounded w-32"></div>
            </div>
            <Building2 className="h-16 w-16 text-primary-200" />
          </div>
        </div>
        <StatsLoading count={4} />
        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="h-6 bg-gray-200 rounded w-48 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 3 }).map((_, index) => (
              <div key={index} className="animate-pulse">
                <div className="h-20 bg-gray-200 rounded-lg"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <ErrorFallback
          error={error}
          onRetry={handleRetry}
          message="Không thể tải dữ liệu dashboard"
        />
      </div>
    );
  }

  const ManagementDashboard = () => (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-primary to-primary-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Chào mừng, {user?.name}</h1>
            <p className="text-primary-100 mt-1">Ban quản lý chung cư</p>
            <p className="text-primary-200 text-sm mt-2">{currentTime}</p>
          </div>
          <Building2 className="h-16 w-16 text-primary-200" />
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Tổng cư dân</p>
              <p className="text-2xl font-bold text-gray-900">{dashboardStats?.residents.total || 0}</p>
            </div>
            <Users className="h-8 w-8 text-blue-600" />
          </div>
          <div className="mt-4 flex items-center text-sm">
            <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-green-600">+{dashboardStats?.residents.pending || 0} chờ duyệt</span>
          </div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Hóa đơn chưa thanh toán</p>
              <p className="text-2xl font-bold text-gray-900">{dashboardStats?.invoices.pending || 0}</p>
            </div>
            <FileText className="h-8 w-8 text-orange-600" />
          </div>
          <div className="mt-4 flex items-center text-sm">
            <AlertTriangle className="h-4 w-4 text-orange-500 mr-1" />
            <span className="text-orange-600">Cần xử lý</span>
          </div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Doanh thu tháng này</p>
              <p className="text-2xl font-bold text-gray-900">
                {dashboardStats?.revenue.monthly ?
                  `${(dashboardStats.revenue.monthly / 1000000).toFixed(1)}M` : '0'
                }
              </p>
            </div>
            <BarChart3 className="h-8 w-8 text-green-600" />
          </div>
          <div className="mt-4 flex items-center text-sm">
            <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-green-600">
              {dashboardStats?.revenue.growth > 0 ? '+' : ''}
              {dashboardStats?.revenue.growth?.toFixed(1) || 0}% so với tháng trước
            </span>
          </div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Hợp đồng sắp hết hạn</p>
              <p className="text-2xl font-bold text-gray-900">{dashboardStats?.contracts.expiring || 0}</p>
            </div>
            <Clock className="h-8 w-8 text-red-600" />
          </div>
          <div className="mt-4 flex items-center text-sm">
            <AlertTriangle className="h-4 w-4 text-red-500 mr-1" />
            <span className="text-red-600">Trong 30 ngày tới</span>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Thao tác nhanh</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <Link
            to="/residents"
            className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <Users className="h-8 w-8 text-blue-600 mr-3" />
            <div>
              <p className="font-medium text-gray-900">Quản lý cư dân</p>
              <p className="text-sm text-gray-600">Duyệt tài khoản, quản lý thông tin</p>
            </div>
          </Link>

          <Link
            to="/services"
            className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <FileText className="h-8 w-8 text-green-600 mr-3" />
            <div>
              <p className="font-medium text-gray-900">Cấu hình dịch vụ</p>
              <p className="text-sm text-gray-600">Thiết lập giá, điều khoản</p>
            </div>
          </Link>

          <Link
            to="/invoices"
            className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <CreditCard className="h-8 w-8 text-purple-600 mr-3" />
            <div>
              <p className="font-medium text-gray-900">Lập hóa đơn</p>
              <p className="text-sm text-gray-600">Tạo và quản lý hóa đơn</p>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );

  const ResidentDashboard = () => (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-primary to-primary-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Xin chào, {user?.name}</h1>
            <p className="text-primary-100 mt-1">Căn hộ {user?.apartmentNumber}</p>
            <p className="text-primary-200 text-sm mt-2">{currentTime}</p>
          </div>
          <Building2 className="h-16 w-16 text-primary-200" />
        </div>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Hợp đồng đang hiệu lực</p>
              <p className="text-2xl font-bold text-gray-900">5</p>
            </div>
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          <p className="text-sm text-green-600 mt-2">Tất cả đều ổn</p>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Hóa đơn chưa thanh toán</p>
              <p className="text-2xl font-bold text-gray-900">3</p>
            </div>
            <FileText className="h-8 w-8 text-orange-600" />
          </div>
          <p className="text-sm text-orange-600 mt-2">Tổng: 2.450.000 VND</p>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Thông báo mới</p>
              <p className="text-2xl font-bold text-gray-900">2</p>
            </div>
            <Bell className="h-8 w-8 text-blue-600" />
          </div>
          <p className="text-sm text-blue-600 mt-2">Có thông báo mới</p>
        </div>
      </div>

      {/* Recent Activities */}
      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Hoạt động gần đây</h2>
        <div className="space-y-4">
          <div className="flex items-center p-3 bg-blue-50 rounded-lg">
            <FileText className="h-5 w-5 text-blue-600 mr-3" />
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-900">Hóa đơn tháng 12 đã được tạo</p>
              <p className="text-xs text-gray-600">2 ngày trước</p>
            </div>
          </div>
          
          <div className="flex items-center p-3 bg-green-50 rounded-lg">
            <CheckCircle className="h-5 w-5 text-green-600 mr-3" />
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-900">Thanh toán hóa đơn tháng 11 thành công</p>
              <p className="text-xs text-gray-600">1 tuần trước</p>
            </div>
          </div>

          <div className="flex items-center p-3 bg-yellow-50 rounded-lg">
            <Bell className="h-5 w-5 text-yellow-600 mr-3" />
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-900">Hợp đồng dịch vụ vệ sinh sắp hết hạn</p>
              <p className="text-xs text-gray-600">3 ngày trước</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Thao tác nhanh</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Link
            to="/payments"
            className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <CreditCard className="h-8 w-8 text-green-600 mr-3" />
            <div>
              <p className="font-medium text-gray-900">Thanh toán hóa đơn</p>
              <p className="text-sm text-gray-600">3 hóa đơn chưa thanh toán</p>
            </div>
          </Link>

          <Link
            to="/my-contracts"
            className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <FileText className="h-8 w-8 text-blue-600 mr-3" />
            <div>
              <p className="font-medium text-gray-900">Xem hợp đồng</p>
              <p className="text-sm text-gray-600">Quản lý 5 hợp đồng</p>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );

  return (
    <div className="p-6">
      {user?.role === 'management' ? <ManagementDashboard /> : <ResidentDashboard />}
    </div>
  );
};

export default Dashboard;
