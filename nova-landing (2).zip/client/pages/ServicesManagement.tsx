import React, { useState } from 'react';
import { 
  Plus, 
  Settings, 
  Edit3, 
  Trash2, 
  Save, 
  X, 
  DollarSign,
  Calendar,
  FileText,
  Zap,
  Droplets,
  Shield,
  Car,
  Wrench,
  Home
} from 'lucide-react';
import { cn } from '../lib/utils';

interface Service {
  id: string;
  name: string;
  category: string;
  price: number;
  unit: string;
  description: string;
  contractTerms: string;
  isActive: boolean;
  icon: string;
}

const ServicesManagement: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'services' | 'contracts'>('services');
  const [showAddService, setShowAddService] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);

  // Mock data
  const services: Service[] = [
    {
      id: '1',
      name: 'Phí quản lý chung cư',
      category: 'management',
      price: 15000,
      unit: 'VND/m²/tháng',
      description: 'Phí quản lý vận hành chung cư hàng tháng',
      contractTerms: 'Thanh toán hàng tháng trước ngày 15. Phí tính theo diện tích căn hộ.',
      isActive: true,
      icon: 'home'
    },
    {
      id: '2',
      name: 'Điện',
      category: 'utilities',
      price: 3500,
      unit: 'VND/kWh',
      description: 'Chi phí điện sinh hoạt',
      contractTerms: 'Thanh toán theo số điện tiêu thụ thực tế. Chốt số đồng hồ cuối tháng.',
      isActive: true,
      icon: 'zap'
    },
    {
      id: '3',
      name: 'Nước',
      category: 'utilities',
      price: 25000,
      unit: 'VND/m³',
      description: 'Chi phí nước sinh hoạt',
      contractTerms: 'Thanh toán theo số nước tiêu thụ thực tế. Chốt số đồng hồ cuối tháng.',
      isActive: true,
      icon: 'droplets'
    },
    {
      id: '4',
      name: 'Dịch vụ bảo vệ',
      category: 'security',
      price: 80000,
      unit: 'VND/căn hộ/tháng',
      description: 'Dịch vụ bảo vệ an ninh 24/7',
      contractTerms: 'Phí cố định hàng tháng cho mỗi căn hộ. Bao gồm bảo vệ 24/7 và camera an ninh.',
      isActive: true,
      icon: 'shield'
    },
    {
      id: '5',
      name: 'Gửi xe máy',
      category: 'parking',
      price: 100000,
      unit: 'VND/xe/tháng',
      description: 'Phí gửi xe máy trong tầng hầm',
      contractTerms: 'Phí tháng cho một xe máy. Cấp thẻ từ ra vào. Mất thẻ phạt 100,000 VND.',
      isActive: true,
      icon: 'car'
    },
    {
      id: '6',
      name: 'Bảo trì thang máy',
      category: 'maintenance',
      price: 50000,
      unit: 'VND/căn hộ/tháng',
      description: 'Chi phí bảo trì thang máy định kỳ',
      contractTerms: 'Phí cố định hàng tháng. Bao gồm bảo trì định kỳ và sửa chữa thang máy.',
      isActive: false,
      icon: 'wrench'
    }
  ];

  const [serviceList, setServiceList] = useState(services);

  const getServiceIcon = (iconName: string) => {
    const icons = {
      home: Home,
      zap: Zap,
      droplets: Droplets,
      shield: Shield,
      car: Car,
      wrench: Wrench
    };
    const Icon = icons[iconName as keyof typeof icons] || Settings;
    return <Icon className="h-5 w-5" />;
  };

  const getCategoryName = (category: string) => {
    const categories = {
      management: 'Quản lý',
      utilities: 'Tiện ích',
      security: 'An ninh',
      parking: 'Gửi xe',
      maintenance: 'Bảo trì'
    };
    return categories[category as keyof typeof categories] || category;
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      management: 'bg-blue-100 text-blue-800',
      utilities: 'bg-green-100 text-green-800',
      security: 'bg-red-100 text-red-800',
      parking: 'bg-purple-100 text-purple-800',
      maintenance: 'bg-orange-100 text-orange-800'
    };
    return colors[category as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const handleToggleService = (serviceId: string) => {
    setServiceList(services => 
      services.map(service => 
        service.id === serviceId 
          ? { ...service, isActive: !service.isActive }
          : service
      )
    );
  };

  const NewServiceForm = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold">Thêm dịch vụ mới</h3>
          <button 
            onClick={() => setShowAddService(false)}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <form className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Tên dịch vụ</label>
              <input
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="Nhập tên dịch vụ"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Danh mục</label>
              <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary">
                <option value="management">Quản lý</option>
                <option value="utilities">Tiện ích</option>
                <option value="security">An ninh</option>
                <option value="parking">Gửi xe</option>
                <option value="maintenance">Bảo trì</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Giá</label>
              <input
                type="number"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="0"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Đơn vị</label>
              <input
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="VND/tháng"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Mô tả</label>
            <textarea
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder="Mô tả chi tiết về dịch vụ"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Điều khoản hợp đồng</label>
            <textarea
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder="Điều khoản và điều kiện áp dụng"
            />
          </div>

          <div className="flex space-x-3 pt-4">
            <button 
              type="button"
              onClick={() => setShowAddService(false)}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              Hủy
            </button>
            <button 
              type="submit"
              className="flex-1 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-600"
            >
              Lưu dịch vụ
            </button>
          </div>
        </form>
      </div>
    </div>
  );

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dịch vụ & Hợp đồng</h1>
          <p className="text-gray-600 mt-1">Quản lý các dịch vụ và điều khoản hợp đồng</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-lg border">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('services')}
              className={cn(
                'py-4 px-1 border-b-2 font-medium text-sm',
                activeTab === 'services'
                  ? 'border-primary text-primary'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              )}
            >
              Danh sách dịch vụ
            </button>
            <button
              onClick={() => setActiveTab('contracts')}
              className={cn(
                'py-4 px-1 border-b-2 font-medium text-sm',
                activeTab === 'contracts'
                  ? 'border-primary text-primary'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              )}
            >
              Mẫu hợp đồng
            </button>
          </nav>
        </div>

        {/* Services Tab */}
        {activeTab === 'services' && (
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Danh sách dịch vụ</h3>
                <p className="text-gray-600">Cấu hình các dịch vụ và mức giá</p>
              </div>
              <button
                onClick={() => setShowAddService(true)}
                className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-600 transition-colors flex items-center"
              >
                <Plus className="h-4 w-4 mr-2" />
                Thêm dịch vụ
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {serviceList.map((service) => (
                <div key={service.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-primary-100 rounded-lg text-primary">
                        {getServiceIcon(service.icon)}
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">{service.name}</h4>
                        <span className={cn('px-2 py-1 rounded-full text-xs font-medium', getCategoryColor(service.category))}>
                          {getCategoryName(service.category)}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button className="text-gray-500 hover:text-gray-700 p-1">
                        <Edit3 className="h-4 w-4" />
                      </button>
                      <button 
                        onClick={() => handleToggleService(service.id)}
                        className={cn(
                          'w-8 h-4 rounded-full transition-colors relative',
                          service.isActive ? 'bg-green-500' : 'bg-gray-300'
                        )}
                      >
                        <div className={cn(
                          'w-3 h-3 bg-white rounded-full transition-transform absolute top-0.5',
                          service.isActive ? 'translate-x-4' : 'translate-x-0.5'
                        )} />
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Giá:</span>
                      <span className="font-medium text-gray-900">
                        {service.price.toLocaleString('vi-VN')} {service.unit}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600">{service.description}</p>
                    <div className="pt-2 border-t">
                      <p className="text-xs text-gray-500">
                        <strong>Điều khoản:</strong> {service.contractTerms}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Contracts Tab */}
        {activeTab === 'contracts' && (
          <div className="p-6">
            <div className="text-center py-12">
              <FileText className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Mẫu hợp đồng</h3>
              <p className="text-gray-600 mb-6">
                Tính năng này đang được phát triển. Sẽ cho phép tạo và quản lý các mẫu hợp đồng.
              </p>
              <div className="max-w-md mx-auto text-left">
                <h4 className="font-medium text-gray-900 mb-2">Tính năng sẽ bao gồm:</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Tạo mẫu hợp đồng cho từng loại dịch vụ</li>
                  <li>• Tùy chỉnh điều khoản và điều kiện</li>
                  <li>• Thiết lập thời hạn hợp đồng mặc định</li>
                  <li>• Quản lý phiên bản mẫu hợp đồng</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Add Service Modal */}
      {showAddService && <NewServiceForm />}
    </div>
  );
};

export default ServicesManagement;
