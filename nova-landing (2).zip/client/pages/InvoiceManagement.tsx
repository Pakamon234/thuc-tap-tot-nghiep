import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  Plus, 
  Eye, 
  Edit3, 
  Download, 
  Send, 
  CheckCircle, 
  Clock, 
  XCircle,
  Calendar,
  DollarSign,
  FileText,
  Building
} from 'lucide-react';
import { cn } from '../lib/utils';

interface Invoice {
  id: string;
  invoiceNumber: string;
  residentName: string;
  apartmentNumber: string;
  amount: number;
  dueDate: string;
  issueDate: string;
  status: 'paid' | 'pending' | 'overdue' | 'cancelled';
  services: {
    name: string;
    amount: number;
    unit: string;
    quantity: number;
  }[];
  paymentDate?: string;
}

const InvoiceManagement: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [monthFilter, setMonthFilter] = useState<string>('all');
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [showDetails, setShowDetails] = useState(false);

  // Mock data
  const invoices: Invoice[] = [
    {
      id: '1',
      invoiceNumber: 'HD-2024-001',
      residentName: 'Nguyễn Văn An',
      apartmentNumber: 'A101',
      amount: 2450000,
      dueDate: '2024-12-15',
      issueDate: '2024-12-01',
      status: 'pending',
      services: [
        { name: 'Phí quản lý', amount: 1200000, unit: 'VND/m²/tháng', quantity: 80 },
        { name: 'Điện', amount: 850000, unit: 'VND/kWh', quantity: 243 },
        { name: 'Nước', amount: 300000, unit: 'VND/m³', quantity: 12 },
        { name: 'Bảo vệ', amount: 100000, unit: 'VND/tháng', quantity: 1 }
      ]
    },
    {
      id: '2',
      invoiceNumber: 'HD-2024-002',
      residentName: 'Trần Thị Bích',
      apartmentNumber: 'B205',
      amount: 1980000,
      dueDate: '2024-12-15',
      issueDate: '2024-12-01',
      status: 'paid',
      services: [
        { name: 'Phí quản lý', amount: 900000, unit: 'VND/m²/tháng', quantity: 60 },
        { name: 'Điện', amount: 680000, unit: 'VND/kWh', quantity: 194 },
        { name: 'Nước', amount: 250000, unit: 'VND/m³', quantity: 10 },
        { name: 'Bảo vệ', amount: 80000, unit: 'VND/tháng', quantity: 1 },
        { name: 'Gửi xe', amount: 100000, unit: 'VND/tháng', quantity: 1 }
      ],
      paymentDate: '2024-12-10'
    },
    {
      id: '3',
      invoiceNumber: 'HD-2024-003',
      residentName: 'Lê Minh Cường',
      apartmentNumber: 'C302',
      amount: 2750000,
      dueDate: '2024-11-15',
      issueDate: '2024-11-01',
      status: 'overdue',
      services: [
        { name: 'Phí quản lý', amount: 1350000, unit: 'VND/m²/tháng', quantity: 90 },
        { name: 'Điện', amount: 920000, unit: 'VND/kWh', quantity: 263 },
        { name: 'Nước', amount: 350000, unit: 'VND/m³', quantity: 14 },
        { name: 'Bảo vệ', amount: 80000, unit: 'VND/tháng', quantity: 1 },
        { name: 'Gửi xe', amount: 200000, unit: 'VND/tháng', quantity: 2 }
      ]
    }
  ];

  const filteredInvoices = invoices.filter(invoice => {
    const matchesSearch = invoice.residentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         invoice.apartmentNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         invoice.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || invoice.status === statusFilter;
    const matchesMonth = monthFilter === 'all' || 
                        new Date(invoice.issueDate).getMonth() === parseInt(monthFilter);
    return matchesSearch && matchesStatus && matchesMonth;
  });

  const getStatusBadge = (status: string) => {
    const styles = {
      pending: 'bg-yellow-100 text-yellow-800',
      paid: 'bg-green-100 text-green-800',
      overdue: 'bg-red-100 text-red-800',
      cancelled: 'bg-gray-100 text-gray-800'
    };
    
    const labels = {
      pending: 'Chờ thanh toán',
      paid: 'Đã thanh toán',
      overdue: 'Quá hạn',
      cancelled: 'Đã hủy'
    };

    const icons = {
      pending: Clock,
      paid: CheckCircle,
      overdue: XCircle,
      cancelled: XCircle
    };

    const Icon = icons[status as keyof typeof icons];

    return (
      <span className={cn('px-2 py-1 rounded-full text-xs font-medium flex items-center', styles[status as keyof typeof styles])}>
        <Icon className="h-3 w-3 mr-1" />
        {labels[status as keyof typeof labels]}
      </span>
    );
  };

  const statistics = [
    { 
      label: 'Tổng hóa đơn', 
      value: invoices.length, 
      color: 'text-blue-600',
      icon: FileText 
    },
    { 
      label: 'Chờ thanh toán', 
      value: invoices.filter(i => i.status === 'pending').length, 
      color: 'text-yellow-600',
      icon: Clock 
    },
    { 
      label: 'Đã thanh toán', 
      value: invoices.filter(i => i.status === 'paid').length, 
      color: 'text-green-600',
      icon: CheckCircle 
    },
    { 
      label: 'Quá hạn', 
      value: invoices.filter(i => i.status === 'overdue').length, 
      color: 'text-red-600',
      icon: XCircle 
    }
  ];

  const totalAmount = invoices.reduce((sum, invoice) => sum + invoice.amount, 0);
  const paidAmount = invoices.filter(i => i.status === 'paid').reduce((sum, invoice) => sum + invoice.amount, 0);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Quản lý hóa đơn</h1>
          <p className="text-gray-600 mt-1">Tạo và quản lý hóa đơn dịch vụ cho cư dân</p>
        </div>
        <button className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-600 transition-colors flex items-center">
          <Plus className="h-4 w-4 mr-2" />
          Tạo hóa đơn
        </button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
        {statistics.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-lg p-4 border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className={cn('text-2xl font-bold', stat.color)}>{stat.value}</p>
                </div>
                <Icon className={cn('h-8 w-8', stat.color)} />
              </div>
            </div>
          );
        })}
        
        <div className="bg-white rounded-lg p-4 border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Tổng doanh thu</p>
              <p className="text-lg font-bold text-blue-600">
                {totalAmount.toLocaleString('vi-VN')} VND
              </p>
            </div>
            <DollarSign className="h-8 w-8 text-blue-600" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Đã thu</p>
              <p className="text-lg font-bold text-green-600">
                {paidAmount.toLocaleString('vi-VN')} VND
              </p>
            </div>
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg p-4 border">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Tìm kiếm theo tên, căn hộ hoặc số hóa đơn..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-gray-500" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="all">Tất cả trạng thái</option>
              <option value="pending">Chờ thanh toán</option>
              <option value="paid">Đã thanh toán</option>
              <option value="overdue">Quá hạn</option>
              <option value="cancelled">Đã hủy</option>
            </select>
          </div>

          <div className="flex items-center space-x-2">
            <Calendar className="h-4 w-4 text-gray-500" />
            <select
              value={monthFilter}
              onChange={(e) => setMonthFilter(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="all">Tất cả tháng</option>
              <option value="0">Tháng 1</option>
              <option value="1">Tháng 2</option>
              <option value="10">Tháng 11</option>
              <option value="11">Tháng 12</option>
            </select>
          </div>
        </div>
      </div>

      {/* Invoices Table */}
      <div className="bg-white rounded-lg border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Hóa đơn
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Cư dân
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Số tiền
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Hạn thanh toán
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Trạng thái
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Thao tác
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredInvoices.map((invoice) => (
                <tr key={invoice.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{invoice.invoiceNumber}</div>
                      <div className="text-sm text-gray-500">
                        Phát hành: {new Date(invoice.issueDate).toLocaleDateString('vi-VN')}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-10 w-10 bg-primary rounded-full flex items-center justify-center text-white font-medium">
                        {invoice.residentName.charAt(0)}
                      </div>
                      <div className="ml-3">
                        <div className="text-sm font-medium text-gray-900">{invoice.residentName}</div>
                        <div className="text-sm text-gray-500 flex items-center">
                          <Building className="h-3 w-3 mr-1" />
                          {invoice.apartmentNumber}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {invoice.amount.toLocaleString('vi-VN')} VND
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">
                      {new Date(invoice.dueDate).toLocaleDateString('vi-VN')}
                    </div>
                    {invoice.status === 'overdue' && (
                      <div className="text-xs text-red-600">Quá hạn</div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {getStatusBadge(invoice.status)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => {setSelectedInvoice(invoice); setShowDetails(true);}}
                        className="text-blue-600 hover:text-blue-900 p-1 rounded"
                        title="Xem chi tiết"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      <button className="text-gray-600 hover:text-gray-900 p-1 rounded" title="Chỉnh sửa">
                        <Edit3 className="h-4 w-4" />
                      </button>
                      <button className="text-green-600 hover:text-green-900 p-1 rounded" title="Tải về">
                        <Download className="h-4 w-4" />
                      </button>
                      <button className="text-purple-600 hover:text-purple-900 p-1 rounded" title="Gửi email">
                        <Send className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredInvoices.length === 0 && (
          <div className="text-center py-8">
            <p className="text-gray-500">Không tìm thấy hóa đơn nào phù hợp</p>
          </div>
        )}
      </div>

      {/* Invoice Details Modal */}
      {showDetails && selectedInvoice && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold">Chi tiết hóa đơn</h3>
              <button 
                onClick={() => setShowDetails(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <XCircle className="h-5 w-5" />
              </button>
            </div>
            
            <div className="space-y-6">
              {/* Invoice Header */}
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium text-gray-900 text-lg">{selectedInvoice.invoiceNumber}</h4>
                    <p className="text-gray-600">{selectedInvoice.residentName}</p>
                    <p className="text-gray-600">Căn hộ: {selectedInvoice.apartmentNumber}</p>
                  </div>
                  <div className="text-right">
                    {getStatusBadge(selectedInvoice.status)}
                    <p className="text-2xl font-bold text-gray-900 mt-2">
                      {selectedInvoice.amount.toLocaleString('vi-VN')} VND
                    </p>
                  </div>
                </div>
              </div>

              {/* Services Details */}
              <div>
                <h5 className="font-medium text-gray-900 mb-3">Chi tiết dịch vụ</h5>
                <div className="space-y-2">
                  {selectedInvoice.services.map((service, index) => (
                    <div key={index} className="flex justify-between items-center py-2 border-b border-gray-100">
                      <div>
                        <span className="font-medium">{service.name}</span>
                        <span className="text-gray-600 text-sm ml-2">
                          ({service.quantity} x {service.unit})
                        </span>
                      </div>
                      <span className="font-medium">{service.amount.toLocaleString('vi-VN')} VND</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Dates */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-600">Ngày phát hành</label>
                  <p className="text-gray-900">{new Date(selectedInvoice.issueDate).toLocaleDateString('vi-VN')}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Hạn thanh toán</label>
                  <p className="text-gray-900">{new Date(selectedInvoice.dueDate).toLocaleDateString('vi-VN')}</p>
                </div>
              </div>

              {selectedInvoice.paymentDate && (
                <div>
                  <label className="text-sm font-medium text-gray-600">Ngày thanh toán</label>
                  <p className="text-green-600 font-medium">{new Date(selectedInvoice.paymentDate).toLocaleDateString('vi-VN')}</p>
                </div>
              )}
            </div>
            
            <div className="flex space-x-3 mt-6">
              <button 
                onClick={() => setShowDetails(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Đóng
              </button>
              <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                <Download className="h-4 w-4 mr-2 inline" />
                Tải PDF
              </button>
              <button className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-600">
                <Edit3 className="h-4 w-4 mr-2 inline" />
                Chỉnh sửa
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InvoiceManagement;
