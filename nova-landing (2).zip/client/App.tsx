import "./global.css";
import "./services/apiTest"; // This will test API connection in development

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import ResidentsManagement from "./pages/ResidentsManagement";
import ServicesManagement from "./pages/ServicesManagement";
import InvoiceManagement from "./pages/InvoiceManagement";
import PaymentReports from "./pages/PaymentReports";
import PlaceholderPage from "./pages/PlaceholderPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user } = useAuth();
  return user ? <Layout>{children}</Layout> : <Navigate to="/login" />;
};

const PublicRoute = ({ children }: { children: React.ReactNode }) => {
  const { user } = useAuth();
  return user ? <Navigate to="/dashboard" /> : <>{children}</>;
};

function AppRoutes() {
  return (
    <Routes>
      {/* Redirect root to dashboard */}
      <Route path="/" element={<Navigate to="/dashboard" />} />

      {/* Public routes */}
      <Route path="/login" element={
        <PublicRoute>
          <Login />
        </PublicRoute>
      } />
      <Route path="/register" element={
        <PublicRoute>
          <Register />
        </PublicRoute>
      } />

      {/* Protected routes */}
      <Route path="/dashboard" element={
        <ProtectedRoute>
          <Dashboard />
        </ProtectedRoute>
      } />

      {/* Management routes */}
      <Route path="/residents" element={
        <ProtectedRoute>
          <ResidentsManagement />
        </ProtectedRoute>
      } />

      <Route path="/services" element={
        <ProtectedRoute>
          <ServicesManagement />
        </ProtectedRoute>
      } />

      <Route path="/invoices" element={
        <ProtectedRoute>
          <InvoiceManagement />
        </ProtectedRoute>
      } />

      <Route path="/reports" element={
        <ProtectedRoute>
          <PaymentReports />
        </ProtectedRoute>
      } />

      {/* Resident routes */}
      <Route path="/my-contracts" element={
        <ProtectedRoute>
          <PlaceholderPage
            title="Hợp đồng của tôi"
            description="Quản lý các hợp đồng dịch vụ của bạn"
            suggestions={[
              "Danh sách hợp đồng đang hiệu lực",
              "Hợp đồng sắp hết hạn",
              "Lịch sử thanh toán",
              "Gia hạn hợp đồng"
            ]}
          />
        </ProtectedRoute>
      } />

      <Route path="/payments" element={
        <ProtectedRoute>
          <PlaceholderPage
            title="Thanh toán online"
            description="Thanh toán hóa đơn dịch vụ trực tuyến"
            suggestions={[
              "Danh sách hóa đơn chưa thanh toán",
              "Thanh toán qua Momo, thẻ tín dụng",
              "Thanh toán qua QR code",
              "Lịch sử giao dịch"
            ]}
          />
        </ProtectedRoute>
      } />

      <Route path="/notifications" element={
        <ProtectedRoute>
          <PlaceholderPage
            title="Thông báo"
            description="Nhận thông báo từ ban quản lý"
            suggestions={[
              "Thông báo hợp đồng sắp hết hạn",
              "Cảnh báo đến kỳ thanh toán",
              "Thông báo từ ban quản lý",
              "Cài đặt thông báo email"
            ]}
          />
        </ProtectedRoute>
      } />

      {/* 404 */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <AuthProvider>
        <BrowserRouter>
          <AppRoutes />
        </BrowserRouter>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

createRoot(document.getElementById("root")!).render(<App />);
