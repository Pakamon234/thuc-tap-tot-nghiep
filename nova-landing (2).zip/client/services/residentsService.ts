import { apiClient, ApiResponse, PaginatedResponse } from './api';

export interface Resident {
  id: string;
  name: string;
  email: string;
  phone: string;
  apartmentNumber: string;
  status: 'pending' | 'approved' | 'rejected' | 'suspended';
  registrationDate: string;
  lastLogin?: string;
}

export interface ResidentFilters {
  search?: string;
  status?: string;
  page?: number;
  limit?: number;
}

export interface ResidentUpdateData {
  name?: string;
  email?: string;
  phone?: string;
  apartmentNumber?: string;
}

export interface ResidentStats {
  total: number;
  pending: number;
  approved: number;
  suspended: number;
  rejected: number;
}

export const residentsService = {
  async getResidents(filters: ResidentFilters = {}): Promise<PaginatedResponse<Resident>> {
    const params = new URLSearchParams();
    if (filters.search) params.append('search', filters.search);
    if (filters.status) params.append('status', filters.status);
    if (filters.page) params.append('page', filters.page.toString());
    if (filters.limit) params.append('limit', filters.limit.toString());
    
    const query = params.toString() ? `?${params.toString()}` : '';
    return await apiClient.get<PaginatedResponse<Resident>>(`/residents${query}`);
  },

  async getResident(id: string): Promise<Resident> {
    const response = await apiClient.get<ApiResponse<Resident>>(`/residents/${id}`);
    return response.data;
  },

  async updateResident(id: string, data: ResidentUpdateData): Promise<Resident> {
    const response = await apiClient.put<ApiResponse<Resident>>(`/residents/${id}`, data);
    return response.data;
  },

  async updateResidentStatus(id: string, status: Resident['status']): Promise<Resident> {
    const response = await apiClient.patch<ApiResponse<Resident>>(`/residents/${id}/status`, { status });
    return response.data;
  },

  async deleteResident(id: string): Promise<void> {
    await apiClient.delete(`/residents/${id}`);
  },

  async getResidentStats(): Promise<ResidentStats> {
    const response = await apiClient.get<ApiResponse<ResidentStats>>('/residents/stats');
    return response.data;
  },

  async createResident(data: Omit<Resident, 'id' | 'registrationDate' | 'lastLogin'>): Promise<Resident> {
    const response = await apiClient.post<ApiResponse<Resident>>('/residents', data);
    return response.data;
  },

  async approveResident(id: string): Promise<Resident> {
    return this.updateResidentStatus(id, 'approved');
  },

  async rejectResident(id: string): Promise<Resident> {
    return this.updateResidentStatus(id, 'rejected');
  },

  async suspendResident(id: string): Promise<Resident> {
    return this.updateResidentStatus(id, 'suspended');
  }
};
