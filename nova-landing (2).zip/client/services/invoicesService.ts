import { apiClient, ApiResponse, PaginatedResponse } from './api';

export interface Invoice {
  id: string;
  invoiceNumber: string;
  residentId: string;
  residentName: string;
  apartmentNumber: string;
  amount: number;
  dueDate: string;
  issueDate: string;
  status: 'paid' | 'pending' | 'overdue' | 'cancelled';
  services: InvoiceService[];
  paymentDate?: string;
  notes?: string;
}

export interface InvoiceService {
  serviceId: string;
  name: string;
  amount: number;
  unit: string;
  quantity: number;
  unitPrice: number;
}

export interface InvoiceFilters {
  search?: string;
  status?: string;
  month?: number;
  year?: number;
  residentId?: string;
  page?: number;
  limit?: number;
}

export interface InvoiceCreateData {
  residentId: string;
  dueDate: string;
  services: {
    serviceId: string;
    quantity: number;
    unitPrice?: number;
  }[];
  notes?: string;
}

export interface InvoiceStats {
  total: number;
  pending: number;
  paid: number;
  overdue: number;
  cancelled: number;
  totalAmount: number;
  paidAmount: number;
  pendingAmount: number;
}

export interface PaymentData {
  amount: number;
  paymentMethod: string;
  paymentDate: string;
  transactionId?: string;
  notes?: string;
}

export const invoicesService = {
  async getInvoices(filters: InvoiceFilters = {}): Promise<PaginatedResponse<Invoice>> {
    const params = new URLSearchParams();
    if (filters.search) params.append('search', filters.search);
    if (filters.status) params.append('status', filters.status);
    if (filters.month) params.append('month', filters.month.toString());
    if (filters.year) params.append('year', filters.year.toString());
    if (filters.residentId) params.append('residentId', filters.residentId);
    if (filters.page) params.append('page', filters.page.toString());
    if (filters.limit) params.append('limit', filters.limit.toString());
    
    const query = params.toString() ? `?${params.toString()}` : '';
    return await apiClient.get<PaginatedResponse<Invoice>>(`/invoices${query}`);
  },

  async getInvoice(id: string): Promise<Invoice> {
    const response = await apiClient.get<ApiResponse<Invoice>>(`/invoices/${id}`);
    return response.data;
  },

  async createInvoice(data: InvoiceCreateData): Promise<Invoice> {
    const response = await apiClient.post<ApiResponse<Invoice>>('/invoices', data);
    return response.data;
  },

  async updateInvoice(id: string, data: Partial<InvoiceCreateData>): Promise<Invoice> {
    const response = await apiClient.put<ApiResponse<Invoice>>(`/invoices/${id}`, data);
    return response.data;
  },

  async deleteInvoice(id: string): Promise<void> {
    await apiClient.delete(`/invoices/${id}`);
  },

  async markAsPaid(id: string, paymentData: PaymentData): Promise<Invoice> {
    const response = await apiClient.post<ApiResponse<Invoice>>(`/invoices/${id}/payment`, paymentData);
    return response.data;
  },

  async cancelInvoice(id: string, reason?: string): Promise<Invoice> {
    const response = await apiClient.patch<ApiResponse<Invoice>>(`/invoices/${id}/cancel`, { reason });
    return response.data;
  },

  async getInvoiceStats(filters?: { month?: number; year?: number }): Promise<InvoiceStats> {
    const params = new URLSearchParams();
    if (filters?.month) params.append('month', filters.month.toString());
    if (filters?.year) params.append('year', filters.year.toString());
    
    const query = params.toString() ? `?${params.toString()}` : '';
    const response = await apiClient.get<ApiResponse<InvoiceStats>>(`/invoices/stats${query}`);
    return response.data;
  },

  async generateInvoicePDF(id: string): Promise<Blob> {
    const response = await fetch(`${apiClient['baseURL']}/invoices/${id}/pdf`, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('auth_token')}`,
      },
    });
    
    if (!response.ok) {
      throw new Error('Failed to generate PDF');
    }
    
    return await response.blob();
  },

  async sendInvoiceEmail(id: string, email?: string): Promise<void> {
    await apiClient.post(`/invoices/${id}/send-email`, { email });
  },

  async bulkCreateInvoices(month: number, year: number): Promise<Invoice[]> {
    const response = await apiClient.post<ApiResponse<Invoice[]>>('/invoices/bulk-create', { month, year });
    return response.data;
  },

  async getResidentInvoices(residentId: string, filters: InvoiceFilters = {}): Promise<PaginatedResponse<Invoice>> {
    const params = new URLSearchParams();
    if (filters.status) params.append('status', filters.status);
    if (filters.month) params.append('month', filters.month.toString());
    if (filters.year) params.append('year', filters.year.toString());
    if (filters.page) params.append('page', filters.page.toString());
    if (filters.limit) params.append('limit', filters.limit.toString());
    
    const query = params.toString() ? `?${params.toString()}` : '';
    return await apiClient.get<PaginatedResponse<Invoice>>(`/residents/${residentId}/invoices${query}`);
  }
};
