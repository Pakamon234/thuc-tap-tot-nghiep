import { apiClient } from './api';

// API Testing Utility
export const testApiConnection = async () => {
  console.log('🧪 Testing API connection...');
  
  try {
    // Test basic connectivity
    const response = await fetch(`${apiClient['baseURL'].replace('/api', '')}/api/ping`);
    console.log('✅ API Server is reachable');
    
    // Test if auth endpoint exists
    try {
      await fetch(`${apiClient['baseURL']}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ test: true })
      });
      console.log('✅ Auth endpoint exists');
    } catch (err) {
      console.log('⚠️  Auth endpoint test failed - this is normal if backend is not implemented yet');
    }
    
    return true;
  } catch (error) {
    console.error('❌ API connection failed:', error);
    console.log('💡 Make sure your backend server is running on the configured URL');
    return false;
  }
};

// Development helper - call this in development to test API
if (import.meta.env.DEV) {
  testApiConnection();
}
