import { apiClient, ApiResponse } from './api';

export interface Service {
  id: string;
  name: string;
  category: string;
  price: number;
  unit: string;
  description: string;
  contractTerms: string;
  isActive: boolean;
  icon: string;
  createdAt: string;
  updatedAt: string;
}

export interface ServiceCreateData {
  name: string;
  category: string;
  price: number;
  unit: string;
  description: string;
  contractTerms: string;
  icon: string;
}

export interface ServiceUpdateData {
  name?: string;
  category?: string;
  price?: number;
  unit?: string;
  description?: string;
  contractTerms?: string;
  icon?: string;
  isActive?: boolean;
}

export interface ServiceCategory {
  id: string;
  name: string;
  description: string;
}

export const servicesService = {
  async getServices(): Promise<Service[]> {
    const response = await apiClient.get<ApiResponse<Service[]>>('/services');
    return response.data;
  },

  async getService(id: string): Promise<Service> {
    const response = await apiClient.get<ApiResponse<Service>>(`/services/${id}`);
    return response.data;
  },

  async createService(data: ServiceCreateData): Promise<Service> {
    const response = await apiClient.post<ApiResponse<Service>>('/services', data);
    return response.data;
  },

  async updateService(id: string, data: ServiceUpdateData): Promise<Service> {
    const response = await apiClient.put<ApiResponse<Service>>(`/services/${id}`, data);
    return response.data;
  },

  async deleteService(id: string): Promise<void> {
    await apiClient.delete(`/services/${id}`);
  },

  async toggleService(id: string): Promise<Service> {
    const response = await apiClient.patch<ApiResponse<Service>>(`/services/${id}/toggle`);
    return response.data;
  },

  async getServiceCategories(): Promise<ServiceCategory[]> {
    const response = await apiClient.get<ApiResponse<ServiceCategory[]>>('/services/categories');
    return response.data;
  },

  async getActiveServices(): Promise<Service[]> {
    const response = await apiClient.get<ApiResponse<Service[]>>('/services?active=true');
    return response.data;
  },

  async getServicesByCategory(category: string): Promise<Service[]> {
    const response = await apiClient.get<ApiResponse<Service[]>>(`/services?category=${category}`);
    return response.data;
  }
};
