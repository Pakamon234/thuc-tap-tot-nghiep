import { apiClient, ApiResponse } from './api';

export interface MonthlyRevenue {
  month: number;
  year: number;
  amount: number;
  apartments: number;
  paymentRate: number;
}

export interface ServiceBreakdown {
  serviceId: string;
  name: string;
  amount: number;
  percentage: number;
  category: string;
}

export interface ApartmentPayment {
  apartmentNumber: string;
  residentName: string;
  residentId: string;
  amount: number;
  status: 'paid' | 'pending' | 'overdue';
  dueDate: string;
  paymentDate?: string;
}

export interface RevenueStats {
  totalRevenue: number;
  monthlyRevenue: number;
  paymentRate: number;
  totalApartments: number;
  paidApartments: number;
  pendingInvoices: number;
  overdueInvoices: number;
  averageMonthlyRevenue: number;
  revenueGrowth: number;
}

export interface ReportFilters {
  startDate?: string;
  endDate?: string;
  month?: number;
  year?: number;
  serviceId?: string;
  apartmentNumber?: string;
  status?: string;
}

export const reportsService = {
  async getRevenueStats(filters: ReportFilters = {}): Promise<RevenueStats> {
    const params = new URLSearchParams();
    if (filters.month) params.append('month', filters.month.toString());
    if (filters.year) params.append('year', filters.year.toString());
    if (filters.startDate) params.append('startDate', filters.startDate);
    if (filters.endDate) params.append('endDate', filters.endDate);
    
    const query = params.toString() ? `?${params.toString()}` : '';
    const response = await apiClient.get<ApiResponse<RevenueStats>>(`/reports/revenue-stats${query}`);
    return response.data;
  },

  async getMonthlyRevenue(year: number): Promise<MonthlyRevenue[]> {
    const response = await apiClient.get<ApiResponse<MonthlyRevenue[]>>(`/reports/monthly-revenue?year=${year}`);
    return response.data;
  },

  async getServiceBreakdown(filters: ReportFilters = {}): Promise<ServiceBreakdown[]> {
    const params = new URLSearchParams();
    if (filters.month) params.append('month', filters.month.toString());
    if (filters.year) params.append('year', filters.year.toString());
    if (filters.startDate) params.append('startDate', filters.startDate);
    if (filters.endDate) params.append('endDate', filters.endDate);
    
    const query = params.toString() ? `?${params.toString()}` : '';
    const response = await apiClient.get<ApiResponse<ServiceBreakdown[]>>(`/reports/service-breakdown${query}`);
    return response.data;
  },

  async getApartmentPayments(filters: ReportFilters = {}): Promise<ApartmentPayment[]> {
    const params = new URLSearchParams();
    if (filters.month) params.append('month', filters.month.toString());
    if (filters.year) params.append('year', filters.year.toString());
    if (filters.status) params.append('status', filters.status);
    if (filters.apartmentNumber) params.append('apartmentNumber', filters.apartmentNumber);
    
    const query = params.toString() ? `?${params.toString()}` : '';
    const response = await apiClient.get<ApiResponse<ApartmentPayment[]>>(`/reports/apartment-payments${query}`);
    return response.data;
  },

  async exportRevenueReport(filters: ReportFilters = {}, format: 'excel' | 'pdf' = 'excel'): Promise<Blob> {
    const params = new URLSearchParams();
    if (filters.month) params.append('month', filters.month.toString());
    if (filters.year) params.append('year', filters.year.toString());
    if (filters.startDate) params.append('startDate', filters.startDate);
    if (filters.endDate) params.append('endDate', filters.endDate);
    params.append('format', format);
    
    const query = params.toString() ? `?${params.toString()}` : '';
    const response = await fetch(`${apiClient['baseURL']}/reports/export/revenue${query}`, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('auth_token')}`,
      },
    });
    
    if (!response.ok) {
      throw new Error('Failed to export report');
    }
    
    return await response.blob();
  },

  async exportPaymentReport(filters: ReportFilters = {}, format: 'excel' | 'pdf' = 'excel'): Promise<Blob> {
    const params = new URLSearchParams();
    if (filters.month) params.append('month', filters.month.toString());
    if (filters.year) params.append('year', filters.year.toString());
    if (filters.status) params.append('status', filters.status);
    params.append('format', format);
    
    const query = params.toString() ? `?${params.toString()}` : '';
    const response = await fetch(`${apiClient['baseURL']}/reports/export/payments${query}`, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('auth_token')}`,
      },
    });
    
    if (!response.ok) {
      throw new Error('Failed to export report');
    }
    
    return await response.blob();
  },

  async getDashboardStats(): Promise<{
    residents: { total: number; pending: number; approved: number; suspended: number };
    invoices: { total: number; pending: number; paid: number; overdue: number };
    revenue: { monthly: number; growth: number };
    contracts: { active: number; expiring: number };
  }> {
    const response = await apiClient.get<ApiResponse<any>>('/reports/dashboard-stats');
    return response.data;
  },

  async getPaymentTrends(period: 'monthly' | 'quarterly' | 'yearly', year: number): Promise<{
    period: string;
    revenue: number;
    paymentRate: number;
    apartments: number;
  }[]> {
    const response = await apiClient.get<ApiResponse<any>>(`/reports/payment-trends?period=${period}&year=${year}`);
    return response.data;
  }
};
